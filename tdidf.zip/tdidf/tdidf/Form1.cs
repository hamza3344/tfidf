﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tdidf
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var tokensentence1 = textBox1.Text.Split(" ");
            double n1 = tokensentence1.Length;
            var tokensentence2 = textBox2.Text.Split(" ");
            double n2 = tokensentence2.Length;
            var ocurencewords1 = tokensentence1.GroupBy(g => g)
                .ToDictionary(g => g.Key, g => g.Count());
            var ocurencewords2 = tokensentence2.GroupBy(g => g)
                .ToDictionary(g => g.Key, g => g.Count());
            Dictionary<string, Tuple<int, int>> ccourencelist = new Dictionary<string, Tuple<int, int>>();
            foreach(var words in ocurencewords1)
            {
                ccourencelist.Add(words.Key, Tuple.Create(ocurencewords1[words.Key]
                    , ocurencewords2.ContainsKey(words.Key) ? ocurencewords2[words.Key] : 0));
                ocurencewords2.Remove(words.Key);
            }
            foreach(var words in ocurencewords2)
            {
                ccourencelist.Add(words.Key, Tuple.Create(0, ocurencewords2[words.Key]));
            }
            Dictionary<string, Tuple<double, double>> tfidfs = new Dictionary<string, Tuple<double, double>>();
            foreach(var item in ccourencelist)
            {
                double idf = Math.Log10(2 / (item.Value.Item1 + item.Value.Item2));
                tfidfs.Add(item.Key, Tuple.Create((item.Value.Item1 / n1) * idf, (item.Value.Item2 / n2) * idf))
                    ;

            }
            foreach(var item in tfidfs)
            {
                MessageBox.Show("" + item.Key + item.Value);
            }
        }
    }
}
